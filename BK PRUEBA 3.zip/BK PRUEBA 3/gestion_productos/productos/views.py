# productos/views.py

from django.shortcuts import render, redirect
from .forms import ProductoForm  # Si usas un formulario para crear productos
from django.contrib.auth import logout
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import authenticate, login
from .models import Marca, Categoria
from .models import Producto

def home_view(request):
    # Lógica para la página de inicio (home)
    return render(request, 'home.html')

def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('crear_producto')  # Redirige a la vista de crear producto
    else:
        form = AuthenticationForm()
    
    return render(request, 'login.html', {'form': form})


def crear_producto_view(request):
    if request.method == 'POST':
        form = ProductoForm(request.POST)
        if form.is_valid():
            form.save()  # Esto guarda el producto
            return redirect('listar_productos')  # Redirigir después de guardar el producto
    else:
        form = ProductoForm()

    return render(request, 'crear_producto.html', {'form': form})

def listar_productos_view(request):
    productos = Producto.objects.all()  # Obtener todos los productos
    return render(request, 'listar_productos.html', {'productos': productos})

def layout_view(request):
    return render(request, 'layout.html')
