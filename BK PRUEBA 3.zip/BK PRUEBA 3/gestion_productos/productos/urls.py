from django.urls import path
from . import views

urlpatterns = [
    path('', views.home_view, name='home'),
    path('login/', views.login_view, name='login'),
    path('crear_producto/', views.crear_producto_view, name='crear_producto'),
    path('listar_productos/', views.listar_productos_view, name='listar_productos'),
    path('layout/', views.layout_view, name='layout'),
]
