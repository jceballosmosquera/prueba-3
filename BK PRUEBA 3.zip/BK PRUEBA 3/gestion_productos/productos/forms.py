from django import forms
from .models import Producto, Marca, Categoria

class ProductoForm(forms.ModelForm):
    categoria = forms.CharField(max_length=100)  # Campo de texto para la categoría
    marca = forms.CharField(max_length=100)  # Campo de texto para la marca
    
    class Meta:
        model = Producto
        fields = ['codigo', 'nombre', 'precio', 'caracteristicas', 'categoria', 'marca']
