from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.views.decorators.cache import never_cache
from django.contrib.auth.models import Group
from django.utils.timezone import now
from django.shortcuts import render, get_object_or_404, redirect
from .models import Categoria, Marca, Producto
from django.views.decorators.csrf import csrf_exempt
from .forms import ProductoForm

productos_registrados = []

@csrf_exempt
def inicio_sesion(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        # Autenticación del usuario
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            # Comprobar si el usuario es administrador
            if user.is_superuser:
                # Aquí podemos asignar el valor a la sesión
                request.session['is_admin_products'] = True
                return redirect('listar_productos')  # Redirige al listado de productos si es administrador
            else:
                request.session['is_admin_products'] = False
                return redirect('acceso_denegado')  # Redirige a la página de acceso denegado si no es administrador
        else:
            # Si las credenciales son incorrectas
            return render(request, 'login.html', {'error': 'Credenciales inválidas'})
    return render(request, 'login.html')

@login_required
@never_cache
def listar_productos(request):
    # Validar si el usuario tiene el grupo ADMIN_PRODUCTS
    if not request.session.get('is_admin_products', False):
        return redirect('acceso_denegado')

    # Muestra todos los productos registrados
    return render(request, 'index.html', {'productos': productos_registrados})

@login_required
@never_cache
def registro_producto(request):
    # Validar si el usuario tiene el grupo ADMIN_PRODUCTS
    if not request.session.get('is_admin_products', False):
        return redirect('acceso_denegado')

    if request.method == 'POST':
        producto = {
            'codigo': request.POST['codigo'],
            'nombre': request.POST['nombre'],
            'marca': request.POST['marca'],
            'caracteristicas': request.POST['caracteristicas'],
        }
        productos_registrados.append(producto)  # Agrega a la lista en memoria
        return redirect('resultado_producto')
    return render(request, 'registro.html')

@login_required
@never_cache
def resultado_producto(request):
    if productos_registrados:
        return render(request, 'resultado.html', {'producto': productos_registrados[-1]})
    return redirect('listar_productos')

@login_required
@never_cache
def consulta_productos(request):
    return render(request, 'consulta.html', {'productos': productos_registrados})

@login_required
def cerrar_sesion(request):
    # Cierra la sesión completamente
    logout(request)
    return redirect('login')  # Redirige al login

@login_required
@never_cache
def despliegue_productos(request):
    # Validar si el usuario tiene el grupo ADMIN_PRODUCTS
    if not request.session.get('is_admin_products', False):
        return redirect('acceso_denegado')

    # Simulación de datos para los menús desplegables
    marcas = ['Marca A', 'Marca B', 'Marca C']
    categorias = ['Categoría 1', 'Categoría 2', 'Categoría 3']
    caracteristicas = ['Característica X', 'Característica Y', 'Característica Z']
    
    productos = []  # Lista vacía, ya que no usamos base de datos

    return render(request, 'despliegue_productos.html', {
        'productos': productos,
        'marcas': marcas,
        'categorias': categorias,
        'caracteristicas': caracteristicas,
    })

@login_required
@never_cache
def acceso_denegado(request):
    # Verifica si el usuario es administrador
    if request.user.is_superuser:
        # Si es un administrador, permite el acceso
        return render(request, 'acceso_denegado.html', {'mensaje': 'Bienvenido administrador.'})
    else:
        # Si no es un administrador, redirige a la página de acceso denegado
        return render(request, 'acceso_denegado.html', {'mensaje': 'No tienes permisos para acceder a esta página.'})

@login_required
@never_cache
def modificar_producto(request, id):
    producto = get_object_or_404(Producto, id=id)
    if request.method == 'POST':
        form = ProductoForm(request.POST, instance=producto)
        if form.is_valid():
            form.save()
            return redirect('gestionar_productos')
    else:
        form = ProductoForm(instance=producto)
    return render(request, 'modificar_producto.html', {'form': form})


@login_required
@never_cache
def detalle_productos(request, codigo):
    producto = get_object_or_404(Producto, codigo=codigo)
    return render(request, 'detalle_productos.html', {'producto': producto})