from ninja import NinjaAPI, Schema
from productos.models import Categoria, Marca, Producto
from django.shortcuts import get_object_or_404
from ninja.security import HttpBearer
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework_simplejwt.authentication import JWTAuthentication
from django.contrib.auth.models import User

# Configuración de seguridad JWT
class JWTBearer(HttpBearer):
    def authenticate(self, request, token):
        try:
            user = JWTAuthentication().get_user(JWTAuthentication().get_validated_token(token))
            return user
        except Exception:
            return None

jwt_auth = JWTBearer()

# Configuración de NinjaAPI
api = NinjaAPI(docs_url="/api/docs")

# Schemas
class ProductoModificarSchema(Schema):
    nombre: str = None
    precio: float = None
    peso: float = None
    largo: float = None
    ancho: float = None
    color: str = None
    categoria_id: int = None
    marca_id: int = None

# Endpoints
@api.get("/", tags=["Root"])
def api_root(request):
    """Root de la API"""
    return {"message": "Bienvenido a la API de Gestión de Productos. Visita /api/docs para la documentación."}

@api.get("/categorias", tags=["Categorías"])
def listar_categorias(request):
    """Obtener listado de categorías"""
    categorias = Categoria.objects.all()
    return [{"id": c.id, "nombre": c.nombre} for c in categorias]

@api.get("/marcas", tags=["Marcas"])
def listar_marcas(request):
    """Obtener listado de marcas"""
    marcas = Marca.objects.all()
    return [{"id": m.id, "nombre": m.nombre} for m in marcas]

@api.get("/productos", tags=["Productos"])
def listar_productos(request, marca_id: int = None, categoria_id: int = None):
    """Obtener listado de productos, con filtros opcionales"""
    productos = Producto.objects.all()
    if marca_id:
        productos = productos.filter(marca_id=marca_id)
    if categoria_id:
        productos = productos.filter(categoria_id=categoria_id)
    return [{"codigo": p.codigo, "nombre": p.nombre, "marca": p.marca.nombre, "precio": p.precio} for p in productos]

@api.get("/productos/{codigo}", tags=["Productos"])
def detalle_producto(request, codigo: str):
    """Obtener detalle de un producto por código"""
    producto = get_object_or_404(Producto, codigo=codigo)
    return {
        "codigo": producto.codigo,
        "nombre": producto.nombre,
        "precio": producto.precio,
        "peso": producto.peso,
        "largo": producto.largo,
        "ancho": producto.ancho,
        "color": producto.color,
        "categoria": producto.categoria.nombre,
        "marca": producto.marca.nombre,
    }

@api.put("/productos/{codigo}", tags=["Productos"], auth=jwt_auth)
def modificar_producto(request, codigo: str, payload: ProductoModificarSchema):
    """Modificar atributos de un producto"""
    producto = get_object_or_404(Producto, codigo=codigo)
    for key, value in payload.dict().items():
        if value is not None:
            setattr(producto, key, value)
    producto.save()
    return {"success": True, "message": "Producto actualizado correctamente"}

@api.post("/token", tags=["Autenticación"])
def obtener_token(request, username: str, password: str):
    """Generar token JWT para autenticación"""
    user = get_object_or_404(User, username=username)
    if not user.check_password(password):
        return {"error": "Credenciales inválidas"}
    refresh = RefreshToken.for_user(user)
    return {"access": str(refresh.access_token), "refresh": str(refresh)}
