usuario administrador 
javiera
Javi1234.

intento de que no es usuario administrador 
Usuario1
Javi1234.